﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.Serialization;

namespace PrjGladiator.Models
{
    public class Report
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Report_Id { get; set; }
        public int Marks { get; set; }

        [IgnoreDataMember]
        [ForeignKey("QuestionSet")]
        public int QuestionSetRef_Id { get; set; }
       
        public QuestionSet QuestionSet { get; set; }
        
        [IgnoreDataMember]
        [ForeignKey("Subject")]
        public int Subject_Ref_Id { get; set; }
        public Subject Subject { get; set; }
   
        [ForeignKey("User")]
        public int UserRef_Id { get; set; }
        public User User { get; set; }
    }

    
}
