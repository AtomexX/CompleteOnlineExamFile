﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PrjGladiator.Migrations
{
    public partial class createDBandTables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
