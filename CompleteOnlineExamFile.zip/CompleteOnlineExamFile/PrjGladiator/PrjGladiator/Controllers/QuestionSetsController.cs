﻿using Microsoft.AspNetCore.Mvc;
using PrjGladiator.Models;
using System.Linq;

//Question for particular subject and level

namespace PrjGladiator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionSetsController : ControllerBase
    {
        AppDBContext _context;
        public QuestionSetsController(AppDBContext db)
        {
            _context = db;
        }
        //Post method to add question based on subject name and level
        [HttpPost]
        public IActionResult AddQuestionSet(string subject_name,int level)
        {
            Subject subject = _context.Subjects.FirstOrDefault(s => s.Subject_Name == subject_name);
            if (subject == null)
            {
                return NotFound();
            }
            var question_set = new QuestionSet
            {
                Subject = subject,
                Level = level
            };
            using (var context = _context)
            {
                context.QuestionSets.Add(question_set);
                context.SaveChanges();
            }
            return Ok(subject);
        }

        //Delete method to delete paticular subject question based on subject and level
        [HttpDelete]
        public IActionResult DeleteQuestionSet(string subject_name, int level)
        {
            Subject subject = _context.Subjects.FirstOrDefault(s => s.Subject_Name == subject_name );
            if (subject == null)
            {
                return NotFound();
            }            
            //questionset 
            var questionsets = _context.QuestionSets.Where(s => s.SubjectRef_Id  == subject.Subject_Id && s.Level == level ).ToList();
            if (questionsets != null)
            {
                foreach (QuestionSet qs in questionsets)
                {
                    //report
                    var reports = _context.Reports.Where(o => o.Subject_Ref_Id == subject.Subject_Id && o.QuestionSetRef_Id == qs.QuestionSet_Id).ToList();
                    if (reports != null)
                    {
                        foreach (Report rp in reports)
                        {
                            _context.Reports.Remove(rp);
                        }
                        _context.SaveChanges();
                    }
                    //question
                    var que = _context.Questions.Where(s => s.QuestionSetRef_Id == qs.QuestionSet_Id).ToList();
                    if(que != null)
                    {
                        foreach(Question q in que)
                        {
                            _context.Questions.Remove(q);
                        }
                        _context.SaveChanges();
                    }
                    _context.QuestionSets.Remove(qs);
                }
                _context.SaveChanges();
            }           
            return Ok("DELTE SUCCESS");
        }
    }
}
