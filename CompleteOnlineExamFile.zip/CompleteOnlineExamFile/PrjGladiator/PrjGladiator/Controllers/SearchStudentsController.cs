﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using PrjGladiator.Models;

namespace PrjGladiator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SearchStudentsController : ControllerBase
    {
        private readonly AppDBContext _context;
        public SearchStudentsController(AppDBContext context)
        {
            _context = context;
        }

        //searching students
        [HttpGet]
        public IActionResult SearchStudents([FromQuery(Name = "subject")] string SubjectName, [FromQuery(Name = "state")] string State, [FromQuery(Name = "city")] string City, [FromQuery(Name = "level")] int level, [FromQuery(Name = "mark")] int Marks)
        {
            var query = (
                         from user in _context.Users
                         join report in _context.Reports
                         on user.User_Id equals report.UserRef_Id
                         join ques in _context.QuestionSets
                         on report.QuestionSetRef_Id equals ques.QuestionSet_Id
                         join sub in _context.Subjects
                         on report.Subject_Ref_Id equals sub.Subject_Id
                         where (sub.Subject_Name==SubjectName && user.State == State && user.City == City && ques.Level == level && Marks <= report.Marks)
                         select new { user.UserName, user.Email, user.MobileNumber, user.City, user.State });
            

            if (query != null)
            {
                return Ok(query);
            }
            else
            {
                return Ok("No data found for your search !");
            }
        }
    }
}
