﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PrjGladiator.Models;

namespace PrjGladiator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationController : ControllerBase
    {
        private readonly AppDBContext _context;
        public RegistrationController(AppDBContext context)
        {
            _context = context;
        }
        // Get Method to fetch users details
        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }
        // Post Method for registration of user
        [HttpPost]
        public async Task<ActionResult<User>> PostUser(User user)
        {
            //if users entered mail id already in database it this will return conflict
            if (TblUserExists(user.Email))
            {
                return Conflict("This email id is already registered"); ;
            }
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return Ok("Registered Succesfully");
        }
        //function to check if user already registered or not
        private bool TblUserExists(string email)
        {
            return _context.Users.Any(e => String.Equals(e.Email, email));
        }

    }
}
