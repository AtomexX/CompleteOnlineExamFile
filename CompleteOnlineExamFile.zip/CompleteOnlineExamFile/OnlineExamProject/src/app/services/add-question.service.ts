import { Injectable } from '@angular/core';
//added
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AddQuestionService {

  constructor() { }


  }

