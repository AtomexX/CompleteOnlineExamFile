export interface IQuestion {
    Question_Desc: string;
    Option1:string;
    Option2:string;
    Option3:string;
    Option4:string;
}