export interface UserForRegister {
    userName:string;
    email:string;
    password:string;
    mobile:string;
    city:string;
    state:string;
    dob:string;
    qualification:string;
    yearOfCompletion:number;
    
}

export interface UserForLogin {
    email:string;
    password:string;
    userName:string;
  
}

export interface Question{
    
}