export class AddQuestion{
  FileID: number=0;
  QuestionID: number=0;
  Question:string="";
  Option1:string="";
  Option2:string="";
  Option3:string="";
  Option4:string="";
  CorrectAnswer:string="";
}
