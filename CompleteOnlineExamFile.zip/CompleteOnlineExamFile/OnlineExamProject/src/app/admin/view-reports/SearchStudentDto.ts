export class SearchStudentDto {


	subject: string="";
	state: string="";
	city: string="";
	levels: string="";
    marks: number=0;

}
