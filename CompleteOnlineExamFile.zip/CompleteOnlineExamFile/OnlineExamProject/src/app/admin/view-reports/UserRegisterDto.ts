export class UserRegisterDto {

	UserName : string="";
	email : string="";
	password : string="";
    mobile : string="";
	city : string="";
	dateOfBirth : string="";
	state : string="";
	qualification : string="";
    yearOfCompletion : number=0;

}
